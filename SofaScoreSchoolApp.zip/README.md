# SofaScore School App
Projeto escolar Android inspirado visualmente em aplicativos de placares esportivos.

## Abrir
1. Abra Android Studio.
2. File > Open e selecione a pasta `SofaScoreSchoolApp`.
3. Aguarde o Gradle Sync.
4. Use um emulador Android API 24+ ou celular com depuração USB.
5. Clique Run.

## Imagens
Os escudos, bandeira e avatar são placeholders vetoriais próprios incluídos em `res/drawable`, então não há arquivos externos faltando. Para trocar o avatar por foto real, adicione uma imagem em `res/drawable` e altere `@drawable/ic_person`.
