package com.example.sofascoreschool
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
class PlayerProfileActivity : AppCompatActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_player_profile); findViewById<View>(R.id.backButton).setOnClickListener { finish() } }
}
