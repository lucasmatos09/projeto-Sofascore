package com.example.sofascoreschool

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.content.ContextCompat

class MatchDetailsActivity : AppCompatActivity() {
    private lateinit var summary: ScrollView
    private lateinit var generic: ScrollView
    private lateinit var lineup: ScrollView
    private val tabIds = listOf(R.id.tabSummary, R.id.tabStats, R.id.tabLineups, R.id.tabTable)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_match_details)
        findViewById<View>(R.id.backButton).setOnClickListener { finish() }
        summary = findViewById(R.id.summaryContent); generic = findViewById(R.id.genericContent); lineup = findViewById(R.id.lineupScroll)
        findViewById<TextView>(R.id.tabSummary).setOnClickListener { showTab(R.id.tabSummary) }
        findViewById<TextView>(R.id.tabStats).setOnClickListener { showTab(R.id.tabStats) }
        findViewById<TextView>(R.id.tabLineups).setOnClickListener { showTab(R.id.tabLineups) }
        findViewById<TextView>(R.id.tabTable).setOnClickListener { showTab(R.id.tabTable) }
        buildLineup()
        buildBench()
    }

    private fun showTab(selected: Int) {
        tabIds.forEach { id ->
            val t=findViewById<TextView>(id); val active=id==selected
            t.setTextColor(ContextCompat.getColor(this, if(active) R.color.sofa_blue else R.color.text_secondary))
            t.setBackgroundColor(ContextCompat.getColor(this, if(active) R.color.sofa_blue_soft else R.color.white))
        }
        summary.visibility = if(selected==R.id.tabSummary) View.VISIBLE else View.GONE
        lineup.visibility = if(selected==R.id.tabLineups) View.VISIBLE else View.GONE
        generic.visibility = if(selected==R.id.tabStats || selected==R.id.tabTable) View.VISIBLE else View.GONE
        if(selected==R.id.tabStats) findViewById<TextView>(R.id.genericText).text = "Estatísticas

Posse de bola     61%  —  39%
Finalizações       16  —  9
No alvo              7  —  4
Escanteios           6  —  3
Faltas                9  —  12
Passes certos       91%  —  86%"
        if(selected==R.id.tabTable) findViewById<TextView>(R.id.genericText).text = "Classificação

1. Manchester City     72 pts
2. Arsenal                  69 pts
3. Liverpool               64 pts
4. Chelsea                 58 pts"
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun buildLineup() {
        val pitch=findViewById<ConstraintLayout>(R.id.pitch)
        val players=listOf(
            Triple("Ederson",31, Pair(50,91)), Triple("Walker",2,Pair(16,72)), Triple("Dias",3,Pair(38,76)), Triple("Stones",5,Pair(62,76)), Triple("Gvardiol",24,Pair(84,72)),
            Triple("Rodri",16,Pair(30,52)), Triple("De Bruyne",17,Pair(50,47)), Triple("Foden",47,Pair(70,52)),
            Triple("Doku",11,Pair(22,27)), Triple("Haaland",9,Pair(50,19)), Triple("Silva",20,Pair(78,27))
        )
        players.forEachIndexed { i,p ->
            val box=LinearLayout(this).apply { id=View.generateViewId(); orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; isClickable=true; isFocusable=true }
            val img=ImageView(this).apply { layoutParams=LinearLayout.LayoutParams(dp(42),dp(42)); setBackgroundResource(R.drawable.bg_circle_gray); setImageResource(R.drawable.ic_person); imageTintList=ContextCompat.getColorStateList(this@MatchDetailsActivity,R.color.text_secondary); setPadding(dp(8),dp(8),dp(8),dp(8)) }
            val name=TextView(this).apply { text="${p.second} ${p.first}"; setTextColor(android.graphics.Color.WHITE); textSize=10f; gravity=Gravity.CENTER; setShadowLayer(2f,1f,1f,android.graphics.Color.DKGRAY) }
            val rating=TextView(this).apply { text= if(p.first=="Haaland") "8.4" else listOf("7.1","7.3","7.0","7.5")[i%4]; setTextColor(android.graphics.Color.WHITE); textSize=10f; setBackgroundResource(R.drawable.bg_rating); setPadding(dp(5),dp(1),dp(5),dp(1)) }
            box.addView(img); box.addView(name); box.addView(rating)
            pitch.addView(box, ConstraintLayout.LayoutParams(dp(82),dp(82)))
            val set=ConstraintSet(); set.clone(pitch)
            set.connect(box.id,ConstraintSet.START,pitch.id,ConstraintSet.START); set.connect(box.id,ConstraintSet.TOP,pitch.id,ConstraintSet.TOP)
            set.setHorizontalBias(box.id,p.third.first/100f); set.setVerticalBias(box.id,p.third.second/100f)
            set.connect(box.id,ConstraintSet.END,pitch.id,ConstraintSet.END); set.connect(box.id,ConstraintSet.BOTTOM,pitch.id,ConstraintSet.BOTTOM); set.applyTo(pitch)
            if(p.first=="Haaland") box.setOnClickListener { startActivity(Intent(this,PlayerProfileActivity::class.java)) }
        }
    }
    private fun buildBench(){
        val bench=findViewById<LinearLayout>(R.id.benchContainer)
        listOf("18 Ortega • Goleiro • 6.8","25 Akanji • Defensor • 7.0","8 Kovacic • Meio-campo • 7.2","10 Grealish • Atacante • 6.9").forEach { label ->
            val row=TextView(this).apply { text=label; textSize=15f; setTextColor(ContextCompat.getColor(this@MatchDetailsActivity,R.color.text_primary)); setBackgroundResource(R.drawable.bg_card); setPadding(dp(14),dp(14),dp(14),dp(14)) }
            bench.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin=dp(8) })
        }
    }
}
