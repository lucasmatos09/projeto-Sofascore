package com.example.sofascoreschool

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<android.view.View>(R.id.matchCityArsenal).setOnClickListener {
            startActivity(Intent(this, MatchDetailsActivity::class.java))
        }
        val categories = listOf(R.id.catAll, R.id.catLive, R.id.catFootball, R.id.catBasket, R.id.catTennis)
        categories.forEach { id -> findViewById<TextView>(id).setOnClickListener { selectCategory(id, categories) } }
        val days = listOf(R.id.dayYesterday, R.id.dayToday, R.id.dayTomorrow)
        days.forEach { id -> findViewById<TextView>(id).setOnClickListener { selectDay(id, days) } }
        listOf(R.id.navGames, R.id.navLeagues, R.id.navFavorites, R.id.navNews).forEach { id ->
            findViewById<TextView>(id).setOnClickListener { v ->
                val label = (v as TextView).text.toString().substringAfter("
")
                Toast.makeText(this, "$label selecionado", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<android.view.View>(R.id.searchButton).setOnClickListener { Toast.makeText(this, "Pesquisa", Toast.LENGTH_SHORT).show() }
    }

    private fun selectCategory(selected: Int, ids: List<Int>) {
        ids.forEach { id ->
            val view = findViewById<TextView>(id)
            val active = id == selected
            view.setBackgroundResource(if (active) R.drawable.bg_selected else R.drawable.bg_unselected)
            view.setTextColor(ContextCompat.getColor(this, if (active) R.color.white else R.color.text_primary))
        }
    }

    private fun selectDay(selected: Int, ids: List<Int>) {
        ids.forEach { id ->
            val view = findViewById<TextView>(id)
            view.setTextColor(ContextCompat.getColor(this, if (id == selected) R.color.sofa_blue else R.color.text_secondary))
            view.setTypeface(null, if (id == selected) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
    }
}
